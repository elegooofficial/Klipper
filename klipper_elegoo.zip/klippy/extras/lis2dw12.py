# Support for reading acceleration data from an ST lis2dw12 chip
#
# Copyright (C) 2023  WangChong <1225093964@qq.com>
#
# This file may be distributed under the terms of the GNU GPLv3 license.

import logging, time, collections, threading, multiprocessing, os
from . import bus, motion_report, adxl345

LIS2DW12_DEVID = 0x0F

LIS2DW12_READ_MODE = 0x80

LIS2DW12_CTRL1          = 0x20
LIS2DW12_CTRL2          = 0x21
LIS2DW12_CTRL3          = 0x22
LIS2DW12_CTRL6          = 0x25
LIS2DW12_CTRL_REG7      = 0x3F
LIS2DW12_FIFO_CTRL      = 0x2E

LIS2DW12_CTRL1_LP_MODE0     = 0
LIS2DW12_CTRL1_LP_MODE1     = 1
LIS2DW12_CTRL1_MODE0        = 2
LIS2DW12_CTRL1_MODE1        = 3
LIS2DW12_CTRL1_ODR0         = 4
LIS2DW12_CTRL1_ODR1         = 5
LIS2DW12_CTRL1_ODR2         = 6
LIS2DW12_CTRL1_ODR3         = 7

LIS2DW12_CTRL2_BDU          = 3

LIS2DW12_CTRL3_SLP_MODE_1   = 0
LIS2DW12_CTRL3_SLP_MODE_SEL = 1
LIS2DW12_CTRL3_H_LACTIVE    = 3
LIS2DW12_CTRL3_LIR          = 4
LIS2DW12_CTRL3_PP_OD        = 5
LIS2DW12_CTRL3_ST1          = 6
LIS2DW12_CTRL3_ST2          = 7


LIS2DW12_CTRL6_LOW_NOISE    = 2
LIS2DW12_CTRL6_FDS          = 3
LIS2DW12_CTRL6_FS0          = 4
LIS2DW12_CTRL6_FS1          = 5
LIS2DW12_CTRL6_BW_FILT0     = 6
LIS2DW12_CTRL6_BW_FILT1     = 7

LIS2DW12_CTRL_REG7_USR_OFF_ON_OUT = 4

QUERY_RATES = {
    25: 0x3, 50: 0x4, 100: 0x05, 200: 0x06,
    400: 0x7, 800: 0x8, 1600: 0x9,
}

LIS2DW12_DEV_ID = 0x44

FREEFALL_ACCEL = 9.87635 * 1000.
SCALE = 0.001952 * FREEFALL_ACCEL # 1.952mg/LSB * Earth gravity in mm/s**2

Accel_Measurement = collections.namedtuple(
    'Accel_Measurement', ('time', 'accel_x', 'accel_y', 'accel_z'))


MIN_MSG_TIME = 0.100
BYTES_PER_SAMPLE = 6
SAMPLES_PER_BLOCK = 10

class LIS2DW12:
    def __init__(self, config):
        self.printer = config.get_printer()
        adxl345.AccelCommandHelper(config, self)
        self.query_rate = 0
        am = {'x': (0, SCALE), 'y': (1, SCALE), 'z': (2, SCALE),
              '-x': (0, -SCALE), '-y': (1, -SCALE), '-z': (2, -SCALE)}
        axes_map = config.getlist('axes_map', ('x','y','z'), count=3)
        if any([a not in am for a in axes_map]):
            raise config.error("Invalid lis2dw12 axes_map parameter")
        self.axes_map = [am[a.strip()] for a in axes_map]
        self.data_rate = config.getint('rate', 1600)
        if self.data_rate not in QUERY_RATES:
            raise config.error("Invalid rate parameter: %d" % (self.data_rate,))
        # Measurement storage (accessed from background thread)
        self.lock = threading.Lock()
        self.raw_samples = []
        # Setup mcu lis2dw12 bulk query code
        self.spi = bus.MCU_SPI_from_config(config, 3, default_speed=5000000)
        self.mcu = mcu = self.spi.get_mcu()
        self.oid = oid = mcu.create_oid()
        self.query_lis2dw12_cmd = self.query_lis2dw12_end_cmd = None
        self.query_lis2dw12_status_cmd = None

        mcu.register_config_callback(self._build_config)
        mcu.register_response(self._handle_lis2dw12_data, "lis2dw12_data", oid)

        # Clock tracking
        self.last_sequence = self.max_query_duration = 0
        self.last_limit_count = self.last_error_count = 0
        self.clock_sync = adxl345.ClockSyncRegression(self.mcu, 640)

        # API server endpoints
        self.api_dump = motion_report.APIDumpHelper(
            self.printer, self._api_update, self._api_startstop, 0.100)
        self.name = config.get_name().split()[-1]
        wh = self.printer.lookup_object('webhooks')
        wh.register_mux_endpoint("lis2dw12/dump_lis2dw12", "sensor", self.name,
                                 self._handle_dump_lis2dw12)

    def _build_config(self):
        cmdqueue = self.spi.get_command_queue()
        self.mcu.add_config_cmd("config_lis2dw12 oid=%d spi_oid=%d"
                           % (self.oid, self.spi.get_oid()))
        self.mcu.add_config_cmd("query_lis2dw12 oid=%d clock=0 rest_ticks=0"
                           % (self.oid,), on_restart=True)
        self.query_lis2dw12_cmd = self.mcu.lookup_command(
            "query_lis2dw12 oid=%c clock=%u rest_ticks=%u", cq=cmdqueue)
        self.query_lis2dw12_end_cmd = self.mcu.lookup_query_command(
            "query_lis2dw12 oid=%c clock=%u rest_ticks=%u",
            "lis2dw12_status oid=%c clock=%u query_ticks=%u next_sequence=%hu"
            " buffered=%c fifo=%c limit_count=%hu", oid=self.oid, cq=cmdqueue)
        self.query_lis2dw12_status_cmd = self.mcu.lookup_query_command(
            "query_lis2dw12_status oid=%c",
            "lis2dw12_status oid=%c clock=%u query_ticks=%u next_sequence=%hu"
            " buffered=%c fifo=%c limit_count=%hu", oid=self.oid, cq=cmdqueue)

    def read_reg(self, reg):
        params = self.spi.spi_transfer([reg | LIS2DW12_READ_MODE, 0x00])
        response = bytearray(params['response'])
        return response[1]
    def set_reg(self, reg, val, minclock=0):
        self.spi.spi_send([reg, val & 0xFF], minclock=minclock)
        stored_val = self.read_reg(reg)
        if stored_val != val:
            raise self.printer.command_error(
                    "Failed to set LIS2DW12 register [0x%x] to 0x%x: got 0x%x. "
                    "This is generally indicative of connection problems "
                    "(e.g. faulty wiring) or a faulty lis2dw12 chip." % (
                        reg, val, stored_val))  
    def lis2dw12_read_reg(self, reg):
        params = self.spi.spi_transfer([reg | LIS2DW12_READ_MODE, 0x00])
        response = bytearray(params['response'])
        return response[1]
    def lis2dw12_write_reg(self, reg, val, minclock=0):
        self.spi.spi_send([reg, val & 0xFF], minclock=minclock)
  
    def lis2dw12_bit(self, bit):
        return bit 

    # Defin LIS2DW12 function
    def lis2dw12_block_data_update_set(self, val):
        gcode = self.printer.lookup_object('gcode')
        val = val << self.lis2dw12_bit(LIS2DW12_CTRL2_BDU)
        reg = self.lis2dw12_read_reg(LIS2DW12_CTRL2)                # LIS2DW12_CTRL2(0X21) BDU
        reg &=  0xF7                                                # clear bdu bit 1111 X111
        reg |= val
        self.lis2dw12_write_reg(LIS2DW12_CTRL2, reg)   

    def lis2dw12_full_scale_set(self, val):
        # gcode = self.printer.lookup_object('gcode')
        val = val << self.lis2dw12_bit(LIS2DW12_CTRL6_FS0)   
        reg = self.lis2dw12_read_reg(LIS2DW12_CTRL6)                # LIS2DW12_CTRL6(0X25) 
        reg &= 0xCF
        reg |= val
        self.lis2dw12_write_reg(LIS2DW12_CTRL6, reg) 

    def lis2dw12_filter_path_set(self, val):
        fds = (val & 0x10) >> 4                                     # then if val is 0x10, fds = 1, else fds = 0
        fds = fds <<  self.lis2dw12_bit(LIS2DW12_CTRL6_FDS)  
        reg = self.lis2dw12_read_reg(LIS2DW12_CTRL6) 
        reg &= 0xF7
        reg |= fds
        self.lis2dw12_write_reg(LIS2DW12_CTRL6, reg)

        reg1 = self.lis2dw12_read_reg(LIS2DW12_CTRL_REG7)
        usr_off_on_out = (val & 0x01)
        usr_off_on_out = usr_off_on_out << self.lis2dw12_bit(LIS2DW12_CTRL_REG7_USR_OFF_ON_OUT)
        reg1 &= 0xEF
        reg1 |= usr_off_on_out
        self.lis2dw12_write_reg(LIS2DW12_CTRL_REG7, reg)

    def lis2dw12_filter_bandwidth_set(self, val):
        # val = val & 0x03
        reg = self.lis2dw12_read_reg(LIS2DW12_CTRL6)
        bw_filt = val << self.lis2dw12_bit(LIS2DW12_CTRL6_BW_FILT0)
        reg &= 0x3F
        reg |= bw_filt 
        self.lis2dw12_write_reg(LIS2DW12_CTRL6, reg)

    def lis2dw12_power_mode_set(self, val):
        # val = val & 0x03
        reg_LIS2DW12_CTRL1 = self.lis2dw12_read_reg(LIS2DW12_CTRL1)
        # mode = val & 0x0c >> 2
        mode = val & 0x0c
        lp_mode = val & 0x03
        reg_LIS2DW12_CTRL1 &= 0xF0
        reg_LIS2DW12_CTRL1 |= mode 
        reg_LIS2DW12_CTRL1 |= lp_mode << self.lis2dw12_bit(LIS2DW12_CTRL1_LP_MODE0)
        self.lis2dw12_write_reg(LIS2DW12_CTRL1, reg_LIS2DW12_CTRL1)

        reg = self.lis2dw12_read_reg(LIS2DW12_CTRL6)  
        low_noise = (val & 0x10) >> 4
        reg &= 0xFB
        reg |= low_noise << self.lis2dw12_bit(LIS2DW12_CTRL6_LOW_NOISE)
        self.lis2dw12_write_reg(LIS2DW12_CTRL6, reg)
    
    def lis2dw12_fifo_watermark_set(self, val):
        val = val & 0x1F
        reg = self.lis2dw12_read_reg(LIS2DW12_FIFO_CTRL)
        reg &= 0xE0
        reg |= val
        self.lis2dw12_write_reg(LIS2DW12_FIFO_CTRL, reg)
    def lis2dw12_fifo_mode_set(self, val):
        val = val & 0x07
        reg = self.lis2dw12_read_reg(LIS2DW12_FIFO_CTRL)
        reg &= 0x1F
        reg |= val << 5
        self.lis2dw12_write_reg(LIS2DW12_FIFO_CTRL, reg)

    def lis2dw12_set_fifo(self, val):
        self.lis2dw12_write_reg(LIS2DW12_FIFO_CTRL, val)


    def lis2dw12_data_rate_set(self, val):
        odr = val << self.lis2dw12_bit(LIS2DW12_CTRL1_ODR0)
        reg_LIS2DW12_CTRL1 = self.lis2dw12_read_reg(LIS2DW12_CTRL1)
        reg_LIS2DW12_CTRL1 &= 0x0F
        reg_LIS2DW12_CTRL1 |= odr 
        self.lis2dw12_write_reg(LIS2DW12_CTRL1, reg_LIS2DW12_CTRL1)
        ans = self.lis2dw12_read_reg(LIS2DW12_CTRL1)

        SLP_MODE_1 = (val & 0x30) >> 4
        reg_LIS2DW12_CTRL3 = self.lis2dw12_read_reg(LIS2DW12_CTRL3)
        reg_LIS2DW12_CTRL3 &= 0x3F
        reg_LIS2DW12_CTRL3 |= SLP_MODE_1 << self.lis2dw12_bit(LIS2DW12_CTRL3_ST1);
        self.lis2dw12_write_reg(LIS2DW12_CTRL3, reg_LIS2DW12_CTRL3)

    def lis2dw12_check_reg(self):
        gcode = self.printer.lookup_object('gcode')
        READ_CTRL1 = self.lis2dw12_read_reg(LIS2DW12_CTRL1)
        READ_CTRL2 = self.lis2dw12_read_reg(LIS2DW12_CTRL2)
        READ_CTRL3 = self.lis2dw12_read_reg(LIS2DW12_CTRL3)
        READ_CTRL6 = self.lis2dw12_read_reg(LIS2DW12_CTRL6)
        READ_FIFO_CTRL = self.lis2dw12_read_reg(LIS2DW12_FIFO_CTRL) 

        gcode.respond_info("[DEBUG]READ_CTRL1:0x%x" % READ_CTRL1)
        gcode.respond_info("[DEBUG]READ_CTRL2:0x%x" % READ_CTRL2)
        gcode.respond_info("[DEBUG]READ_CTRL3:0x%x" % READ_CTRL3)
        gcode.respond_info("[DEBUG]READ_CTRL6:0x%x" % READ_CTRL6)
        gcode.respond_info("[DEBUG]READ_FIFO_CTRL:0x%x" % READ_FIFO_CTRL)

    # Measurement collection
    def is_measuring(self):
        return self.query_rate > 0
    def _handle_lis2dw12_data(self, params):
        with self.lock:
            self.raw_samples.append(params)

    def _extract_samples(self, raw_samples):
        # Load variables to optimize inner loop below
        (x_pos, x_scale), (y_pos, y_scale), (z_pos, z_scale) = self.axes_map
        last_sequence = self.last_sequence
        time_base, chip_base, inv_freq = self.clock_sync.get_time_translation()
        # Process every message in raw_samples
        count = seq = 0
        samples = [None] * (len(raw_samples) * SAMPLES_PER_BLOCK)

        for params in raw_samples:
            seq_diff = (last_sequence - params['sequence']) & 0xffff
            seq_diff -= (seq_diff & 0x8000) << 1
            seq = last_sequence - seq_diff
            d = bytearray(params['data'])
            msg_cdiff = seq * SAMPLES_PER_BLOCK - chip_base
            for i in range(len(d) // BYTES_PER_SAMPLE):
                d_xyz = d[i*BYTES_PER_SAMPLE:(i+1)*BYTES_PER_SAMPLE]
                xlow, ylow, zlow, xhigh, yhigh, zhigh = d_xyz 

                rx = (((((xhigh) << 8)|(xlow)) - ((xhigh & 0x80) << 9))  / 4)
                ry = (((((yhigh) << 8)|(ylow)) - ((yhigh & 0x80) << 9))  / 4)
                rz = (((((zhigh) << 8)|(zlow)) - ((zhigh & 0x80) << 9))  / 4)  

                raw_xyz = (rx, ry, rz)

                x = round(raw_xyz[x_pos] * x_scale, 6)
                y = round(raw_xyz[y_pos] * y_scale, 6)
                z = round(raw_xyz[z_pos] * z_scale, 6)

                ptime = round(time_base + (msg_cdiff + i) * inv_freq, 6)
                samples[count] = (ptime, x, y, z)
                count += 1
        self.clock_sync.set_last_chip_clock(seq * SAMPLES_PER_BLOCK + i)
        del samples[count:]
        return samples
    
    def _update_clock(self, minclock=0):
        # Query current state
        for retry in range(5):
            params = self.query_lis2dw12_status_cmd.send([self.oid],
                                                        minclock=minclock)
            fifo = params['fifo'] & 0x7f  #chayan 1
            if fifo <= 32:
                break
        else:
            raise self.printer.command_error("Unable to query lis2dw12 fifo")
        mcu_clock = self.mcu.clock32_to_clock64(params['clock'])
        sequence = (self.last_sequence & ~0xffff) | params['next_sequence']
        if sequence < self.last_sequence:
            sequence += 0x10000
        self.last_sequence = sequence
        buffered = params['buffered']
        limit_count = (self.last_limit_count & ~0xffff) | params['limit_count']
        if limit_count < self.last_limit_count:
            limit_count += 0x10000
        self.last_limit_count = limit_count
        duration = params['query_ticks']
        if duration > self.max_query_duration:
            # Skip measurement as a high query time could skew clock tracking
            self.max_query_duration = max(2 * self.max_query_duration,
                                          self.mcu.seconds_to_clock(.000005))
            return
        self.max_query_duration = 2 * duration
        msg_count = (sequence * SAMPLES_PER_BLOCK
                     + buffered // BYTES_PER_SAMPLE + fifo)

        # The "chip clock" is the message counter plus .5 for average
        # inaccuracy of query responses and plus .5 for assumed offset
        # of lis2dw12 hw processing time.
        chip_clock = msg_count + 1
        self.clock_sync.update(mcu_clock + duration // 2, chip_clock)

    def _start_measurements(self):
        if self.is_measuring():
            return
        # In case of miswiring, testing LIS2DW12 device ID prevents treating
        # noise or wrong signal as a correctly initialized device

        dev_id = self.read_reg(LIS2DW12_DEVID)

        if dev_id != LIS2DW12_DEV_ID:
            raise self.printer.command_error(
                "Invalid lis2dw12 id (got %x vs %x).\n"
                "This is generally indicative of connection problems\n"
                "(e.g. faulty wiring) or a faulty lis2dw12 chip."
                % (dev_id, LIS2DW12_DEV_ID))
        # Setup chip in requested query rate
        self.lis2dw12_block_data_update_set(0x01)       # 0x01
        self.lis2dw12_full_scale_set(0x03)              # 0x03 = 16g, 0x00 = 2g
        self.lis2dw12_filter_path_set(0x00)
        self.lis2dw12_filter_bandwidth_set(0x01)

        # config fifo
        # 0x00(000b):Bypass mode
        # 0x01(001b):FIFO mode 
        # 0x03(011b):Continuous-FIFO mode
        # 0x04(100b):Bypass-Continuous mdoe
        # 0x06(110b):Continuous mode   
        self.lis2dw12_fifo_mode_set(0x06)           

        # Set mode 
        self.lis2dw12_power_mode_set(0x40)          # set 14bit mode
        # Set data rate
        self.lis2dw12_data_rate_set(QUERY_RATES[self.data_rate])           # 1.6MHz

        # self.lis2dw12_check_reg()

        # Setup samples
        with self.lock:
            self.raw_samples = []
        # Start bulk reading
        systime = self.printer.get_reactor().monotonic()
        print_time = self.mcu.estimated_print_time(systime) + MIN_MSG_TIME
        reqclock = self.mcu.print_time_to_clock(print_time)
        rest_ticks = self.mcu.seconds_to_clock(4. / self.data_rate)
        self.query_rate = self.data_rate
        self.query_lis2dw12_cmd.send([self.oid, reqclock, rest_ticks],
                                    reqclock=reqclock)
        logging.info("LIS2DW12 starting '%s' measurements", self.name)

        # Initialize clock tracking
        self.last_sequence = 0
        self.last_limit_count = self.last_error_count = 0
        self.clock_sync.reset(reqclock, 0)
        self.max_query_duration = 1 << 31
        self._update_clock(minclock=reqclock)
        self.max_query_duration = 1 << 31

    def _finish_measurements(self):
        if not self.is_measuring():
            return
        # Halt bulk reading
        params = self.query_lis2dw12_end_cmd.send([self.oid, 0, 0])
        self.query_rate = 0
        with self.lock:
            self.raw_samples = []
        logging.info("LIS2DW12 finished '%s' measurements", self.name)
    # API interface
    def _api_update(self, eventtime):
        self._update_clock()
        with self.lock:
            raw_samples = self.raw_samples
            self.raw_samples = []
        if not raw_samples:
            return {}
        samples = self._extract_samples(raw_samples)
        if not samples:
            return {}
        return {'data': samples, 'errors': self.last_error_count,
                'overflows': self.last_limit_count}
    def _api_startstop(self, is_start):
        if is_start:
            self._start_measurements()
        else:
            self._finish_measurements()
    def _handle_dump_lis2dw12(self, web_request):
        self.api_dump.add_client(web_request)
        hdr = ('time', 'x_acceleration', 'y_acceleration', 'z_acceleration')
        web_request.send({'header': hdr})
    def start_internal_client(self):
        cconn = self.api_dump.add_internal_client()
        return adxl345.AccelQueryHelper(self.printer, cconn)

def load_config(config):
    return LIS2DW12(config)

def load_config_prefix(config):
    return LIS2DW12(config)