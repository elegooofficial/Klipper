Programmable Real-time Unit (PRU) Software Support Package
------------------------------------------------------------
============================================================
   INCLUDE
============================================================

DESCRIPTION

   This directory provides header files for PRU firmware.

   For more details about these header files, visit:

       http://processors.wiki.ti.com/index.php/PRU-ICSS_Header_Files



ADDITIONAL RESOURCES

   For more information about the PRU, visit:

	PRU-ICSS Wiki            - http://processors.wiki.ti.com/index.php/PRU-ICSS
	PRU Training Slides      - http://www.ti.com/sitarabootcamp
	PRU Evaluation Hardware  - http://www.ti.com/tool/PRUCAPE
        Support                  - http://e2e.ti.com

